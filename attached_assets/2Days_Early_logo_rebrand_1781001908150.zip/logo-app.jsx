/* global React, DesignCanvas, DCSection, DCArtboard, DCPostIt */
// ════════════════════════════════════════════════════════════
//  2 Days Early — logo exploration canvas
// ════════════════════════════════════════════════════════════
const { IconCell2DE, WeekGrid, Wordmark, MiniMark, Cell } = window;

const MONO = 'var(--font-mono)';
const GROT = 'var(--font-grotesque)';

// ── small helpers ────────────────────────────────────────────
function Field({ theme = 'dark', children, style = {}, pad = 56 }) {
  return (
    <div
      className={`grain ${theme === 'dark' ? 'field-dark' : theme === 'emerald' ? 'field-emerald' : 'field-light'}`}
      style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: pad, boxSizing: 'border-box', position: 'relative', ...style }}
    >
      {children}
    </div>
  );
}

function Tag({ children, theme = 'dark' }) {
  return (
    <div style={{
      position: 'absolute', left: 16, bottom: 14, fontFamily: MONO, fontSize: 11,
      letterSpacing: '0.08em', textTransform: 'uppercase',
      color: theme === 'dark' ? 'rgba(167,240,198,0.6)' : 'rgba(14,59,46,0.5)',
    }}>{children}</div>
  );
}

// ════════════════════════════════════════════════════════════
//  FOUNDATIONS
// ════════════════════════════════════════════════════════════
function Foundations() {
  const swatches = [
    ['Forest', '#0E3B2E', '#fff'], ['Forest deep', '#082A20', '#fff'],
    ['Emerald', '#22C55E', '#06311f'], ['Emerald bright', '#2BD46E', '#06311f'],
    ['Mint', '#A7F0C6', '#06311f'], ['Edge light', '#9BF7D2', '#06311f'],
    ['Paper', '#F4F9F6', '#0E3B2E'],
  ];
  return (
    <div style={{ width: '100%', height: '100%', display: 'grid', gridTemplateColumns: '1.05fr 1fr', background: '#fff' }}>
      {/* left: dark material panel */}
      <div className="grain field-dark" style={{ position: 'relative', padding: 44, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
        <div style={{ fontFamily: MONO, fontSize: 12, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'rgba(167,240,198,0.7)' }}>
          Structured&nbsp;Liquidity · the material
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 28 }}>
          <IconCell2DE size={150} theme="dark" />
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,64px)', gap: 12 }}>
            <Cell size={64} variant="glass-emerald" style={{ color: '#fff' }}>2</Cell>
            <Cell size={64} variant="glass" style={{ color: 'var(--mint)' }}>D</Cell>
            <Cell size={64} variant="glass-mint" style={{ color: 'var(--forest)' }}>E</Cell>
            <Cell size={64} variant="glass-forest" style={{ color: 'var(--emerald-300)' }}>W</Cell>
          </div>
        </div>
        <div style={{ fontFamily: GROT, fontWeight: 500, fontSize: 15, lineHeight: 1.5, color: 'rgba(234,251,241,0.78)', maxWidth: 420 }}>
          Rigid grid &times; liquid glass. The calendar structure stays exact and systematic;
          each cell becomes a refractive glass tile. Wednesday — &ldquo;two days early&rdquo; — is the lit hero.
        </div>
      </div>
      {/* right: palette + type */}
      <div style={{ padding: 44, display: 'flex', flexDirection: 'column', gap: 26 }}>
        <div>
          <div style={{ fontFamily: MONO, fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#7c907f', marginBottom: 14 }}>Palette</div>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            {swatches.map(([name, hex, tx]) => (
              <div key={name} className="swatch" style={{ width: 92, height: 64, background: hex, color: tx, borderRadius: 10, padding: 8, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
                <div style={{ fontFamily: GROT, fontWeight: 700, fontSize: 11.5 }}>{name}</div>
                <div style={{ fontFamily: MONO, fontSize: 9.5, opacity: 0.8 }}>{hex}</div>
              </div>
            ))}
          </div>
        </div>
        <div>
          <div style={{ fontFamily: MONO, fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#7c907f', marginBottom: 10 }}>Type — Archivo (Helvetica lineage)</div>
          <div style={{ fontFamily: GROT, fontWeight: 900, fontSize: 46, letterSpacing: '-0.04em', color: 'var(--forest)', lineHeight: 0.95 }}>
            2 DAYS <span style={{ color: 'var(--emerald)' }}>EARLY</span>
          </div>
          <div style={{ fontFamily: MONO, fontSize: 13, letterSpacing: '0.02em', color: '#5a6e60', marginTop: 8 }}>
            operator-led · we get in two days early
          </div>
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════
//  DIRECTION 5 — Ledger / mono systematic
// ════════════════════════════════════════════════════════════
function LedgerMark({ theme = 'dark' }) {
  const dark = theme === 'dark';
  const line = dark ? 'rgba(155,247,210,0.18)' : 'rgba(14,59,46,0.14)';
  const txt = dark ? 'rgba(167,240,198,0.7)' : 'rgba(14,59,46,0.55)';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 26, position: 'relative' }}>
      <div style={{ position: 'relative' }}>
        {/* coordinate ticks */}
        <div style={{ position: 'absolute', top: -22, left: 0, right: 0, display: 'flex', justifyContent: 'space-between', fontFamily: MONO, fontSize: 10, letterSpacing: '0.1em', color: txt }}>
          <span>MON</span><span>WED</span><span>FRI</span>
        </div>
        <div style={{ border: `1px solid ${line}`, borderRadius: 4, padding: 3, display: 'flex', gap: 3 }}>
          {[0, 1, 2, 3, 4].map((i) => (
            <div key={i} className={i === 2 ? 'spec glass-emerald' : ''} style={{
              width: 30, height: 56, borderRadius: 3,
              background: i === 2 ? undefined : (dark ? 'rgba(255,255,255,0.06)' : 'rgba(14,59,46,0.05)'),
              border: i === 2 ? 'none' : `1px solid ${line}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: MONO, fontWeight: 800, fontSize: 22,
              color: i === 2 ? '#fff' : (dark ? 'rgba(167,240,198,0.35)' : 'rgba(14,59,46,0.3)'),
            }}>{i === 2 ? '2' : ''}</div>
          ))}
        </div>
      </div>
      <div>
        <div className="wm-mono" style={{ fontSize: 30, color: dark ? '#fff' : 'var(--forest)', lineHeight: 1 }}>
          2DAYS<span style={{ color: 'var(--emerald-bright)' }}>EARLY</span>
        </div>
        <div style={{ fontFamily: MONO, fontSize: 11.5, letterSpacing: '0.05em', color: txt, marginTop: 7 }}>
          [ syndicate · est. early ]
        </div>
      </div>
    </div>
  );
}

// ── Ledger, iconified — the hairline strip as a square mark ──
function LedgerIcon({ size = 200, theme = 'dark', label = true, ticks = true }) {
  const dark = theme === 'dark';
  const line = dark ? 'rgba(155,247,210,0.24)' : 'rgba(14,59,46,0.18)';
  const dim = dark ? 'rgba(167,240,198,0.45)' : 'rgba(14,59,46,0.35)';
  const cellW = size * 0.108;
  const cellH = size * 0.40;
  return (
    <div
      className={`spec ${dark ? 'glass-forest' : 'glass-mint'}`}
      style={{ width: size, height: size, borderRadius: size * 0.2, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: size * 0.06 }}
    >
      {ticks && (
        <div style={{ display: 'flex', gap: cellW * 0.42, fontFamily: MONO, fontWeight: 500, fontSize: size * 0.06, letterSpacing: '0.04em', color: dim }}>
          <span>M</span><span>T</span><span style={{ color: dark ? 'var(--mint)' : 'var(--forest)' }}>W</span><span>T</span><span>F</span>
        </div>
      )}
      <div style={{ display: 'flex', gap: size * 0.026, padding: size * 0.024, border: `1px solid ${line}`, borderRadius: size * 0.055 }}>
        {[0, 1, 2, 3, 4].map((i) => (
          <div key={i} className={i === 2 ? 'spec glass-emerald' : ''} style={{
            width: cellW, height: cellH, borderRadius: size * 0.03,
            border: i === 2 ? 'none' : `1px solid ${line}`,
            background: i === 2 ? undefined : (dark ? 'rgba(255,255,255,0.05)' : 'rgba(14,59,46,0.045)'),
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: MONO, fontWeight: 800, fontSize: size * 0.21, color: '#fff',
            textShadow: i === 2 ? '0 1px 2px rgba(7,55,37,0.45)' : 'none',
          }}>{i === 2 ? '2' : ''}</div>
        ))}
      </div>
      {label && (
        <div className="wm-mono" style={{ fontSize: size * 0.12, color: dark ? '#fff' : 'var(--forest)', letterSpacing: '-0.01em' }}>
          2<span style={{ color: 'var(--emerald-bright)' }}>DE</span>
        </div>
      )}
    </div>
  );
}

function LedgerIconRamp() {
  const sizes = [96, 64, 48, 32, 16];
  return (
    <div className="grain field-dark" style={{ width: '100%', height: '100%', padding: 44, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 22, position: 'relative' }}>
      <div style={{ fontFamily: MONO, fontSize: 11, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'rgba(167,240,198,0.65)' }}>Ledger icon — favicon legibility</div>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 30 }}>
        {sizes.map((px) => (
          <div key={px} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 9 }}>
            <LedgerIcon size={px} theme="dark" label={false} ticks={px >= 48} />
            <div style={{ fontFamily: MONO, fontSize: 10, color: 'rgba(167,240,198,0.5)' }}>{px}px</div>
          </div>
        ))}
      </div>
      <Tag theme="dark">strip stays legible; ticks drop below 48px</Tag>
    </div>
  );
}

// ── Ledger as a BOLD icon tile — strip is the whole mark ─────
function LedgerTile({ size = 180, theme = 'dark' }) {
  const dark = theme === 'dark';
  const line = dark ? 'rgba(155,247,210,0.30)' : 'rgba(14,59,46,0.22)';
  const cellW = size * 0.128, cellH = size * 0.5, gap = size * 0.036;
  return (
    <div className={`spec ${dark ? 'glass-forest' : 'glass-mint'}`} style={{ width: size, height: size, borderRadius: size * 0.225, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ display: 'flex', gap }}>
        {[0, 1, 2, 3, 4].map((i) => (
          <div key={i} className={i === 2 ? 'spec glass-emerald' : ''} style={{
            width: cellW, height: cellH, borderRadius: size * 0.04,
            border: i === 2 ? 'none' : `1.5px solid ${line}`,
            background: i === 2 ? undefined : (dark ? 'rgba(255,255,255,0.06)' : 'rgba(14,59,46,0.05)'),
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: MONO, fontWeight: 800, fontSize: size * 0.3, color: '#fff',
            textShadow: i === 2 ? '0 1px 3px rgba(7,55,37,0.5)' : 'none',
          }}>{i === 2 ? '2' : ''}</div>
        ))}
      </div>
    </div>
  );
}

// ── Home-screen style comparison of the icon candidates ──────
function IconTileCompare({ theme = 'dark' }) {
  const dark = theme === 'dark';
  const lab = { fontFamily: GROT, fontWeight: 700, fontSize: 14, color: dark ? 'rgba(234,251,241,0.85)' : 'var(--forest)' };
  const sub = { fontFamily: MONO, fontSize: 10.5, letterSpacing: '0.04em', color: dark ? 'rgba(167,240,198,0.55)' : 'rgba(14,59,46,0.5)', marginTop: 3 };
  const tiles = [
    { node: <IconCell2DE size={132} theme={theme} />, name: 'Glass Cell', tag: 'the app icon' },
    { node: <MiniMark size={132} theme={theme} />, name: 'Distilled', tag: 'big 2DE + pips' },
    { node: <LedgerTile size={132} theme={theme} />, name: 'Ledger', tag: 'lit strip, no text' },
  ];
  return (
    <Field theme={theme} style={{ gap: 48 }} pad={48}>
      {tiles.map((t) => (
        <div key={t.name} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
          {t.node}
          <div style={{ textAlign: 'center' }}>
            <div style={lab}>{t.name}</div>
            <div style={sub}>{t.tag}</div>
          </div>
        </div>
      ))}
    </Field>
  );
}

// ════════════════════════════════════════════════════════════
//  FAVICONS
// ════════════════════════════════════════════════════════════
function FaviconBadge({ kind = 'cell', px = 64 }) {
  // simplified marks tuned for tiny sizes
  if (kind === '2') {
    return (
      <div className="spec glass-forest" style={{ width: px, height: px, borderRadius: px * 0.22, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <span style={{ fontFamily: GROT, fontWeight: 900, fontSize: px * 0.62, letterSpacing: '-0.04em', color: 'var(--emerald-bright)', lineHeight: 1 }}>2</span>
      </div>
    );
  }
  if (kind === 'hero') {
    return (
      <div className="spec glass-emerald" style={{ width: px, height: px, borderRadius: px * 0.22, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <span style={{ fontFamily: GROT, fontWeight: 900, fontSize: px * 0.5, letterSpacing: '-0.05em', color: '#fff', lineHeight: 1, textShadow: '0 1px 2px rgba(7,55,37,0.4)' }}>2DE</span>
      </div>
    );
  }
  // default: 2DE on forest, no W (cleaner small)
  return (
    <div className="spec glass-forest" style={{ width: px, height: px, borderRadius: px * 0.22, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <span style={{ fontFamily: GROT, fontWeight: 900, fontSize: px * 0.34, letterSpacing: '-0.05em', lineHeight: 1 }}>
        <span style={{ color: '#fff' }}>2</span><span style={{ color: 'var(--emerald-bright)' }}>DE</span>
      </span>
    </div>
  );
}

function FaviconRow({ kind, label }) {
  const sizes = [128, 64, 48, 32, 24, 16];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div style={{ fontFamily: MONO, fontSize: 11, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(167,240,198,0.65)' }}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 22 }}>
        {sizes.map((px) => (
          <div key={px} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
            <FaviconBadge kind={kind} px={px} />
            <div style={{ fontFamily: MONO, fontSize: 10, color: 'rgba(167,240,198,0.5)' }}>{px}px</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Favicons() {
  return (
    <div className="grain field-dark" style={{ width: '100%', height: '100%', padding: 48, display: 'flex', flexDirection: 'column', justifyContent: 'space-evenly', position: 'relative' }}>
      <FaviconRow kind="cell" label="A · 2DE — primary favicon" />
      <FaviconRow kind="2" label="B · Bold 2 — clearest at 16–32px" />
      <FaviconRow kind="hero" label="C · Emerald hero cell" />
      <Tag theme="dark">favicon.ico · apple-touch-icon · 16 → 512</Tag>
    </div>
  );
}

// ════════════════════════════════════════════════════════════
//  MOTION — animated site header
// ════════════════════════════════════════════════════════════
function AnimatedHeader() {
  return (
    <div className="grain field-dark" style={{ width: '100%', height: '100%', position: 'relative', display: 'flex', flexDirection: 'column' }}>
      {/* nav bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '22px 40px', borderBottom: '1px solid rgba(155,247,210,0.12)' }}>
        <div className="ah-lockup" style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div className="ah-icon" style={{ position: 'relative' }}>
            <IconCell2DE size={52} theme="dark" />
            <div className="ah-sweep" />
          </div>
          <div className="wm" style={{ fontSize: 23, color: '#fff' }}>
            2 DAYS <span style={{ color: 'var(--emerald-bright)' }}>EARLY</span>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 30, fontFamily: GROT, fontWeight: 600, fontSize: 14.5, letterSpacing: '0.01em', color: 'rgba(234,251,241,0.8)' }}>
          <span>Thesis</span><span>Portfolio</span><span>Founders</span>
          <span style={{ color: 'var(--forest)', background: 'var(--emerald-bright)', padding: '7px 16px', borderRadius: 8, fontWeight: 800 }}>Apply</span>
        </div>
      </div>
      {/* hero strip with assembling week grid */}
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 40px' }}>
        <div style={{ maxWidth: 360 }}>
          <div className="wm" style={{ fontSize: 40, lineHeight: 0.95, color: '#fff' }}>
            WE GET IN<br /><span style={{ color: 'var(--emerald-bright)' }}>TWO DAYS EARLY.</span>
          </div>
          <div style={{ fontFamily: MONO, fontSize: 12.5, letterSpacing: '0.03em', color: 'rgba(167,240,198,0.7)', marginTop: 14 }}>
            operator-led pre-seed &amp; seed syndicate
          </div>
        </div>
        <div className="ah-grid" style={{ position: 'relative' }}>
          <WeekGrid unit={52} theme="dark" gap={6} />
          <div className="ah-sweep delay" />
        </div>
      </div>
      <Tag theme="dark">header — glass sweep + Wednesday shimmer · loops</Tag>
    </div>
  );
}

// ════════════════════════════════════════════════════════════
//  APP
// ════════════════════════════════════════════════════════════
function App() {
  return (
    <DesignCanvas>
      <DCSection id="foundations" title="Foundations" subtitle="The material, palette & type behind every mark">
        <DCArtboard id="found" label="System" width={920} height={430}><Foundations /></DCArtboard>
      </DCSection>

      <DCSection id="d1" title="01 · The Glass Cell" subtitle="Faithful re-cut of the app icon — W tab + 2DE, rebuilt in glass">
        <DCArtboard id="d1-dark" label="Dark field" width={360} height={360} style={{ background: '#0E3B2E' }}><Field theme="dark"><IconCell2DE size={228} theme="dark" /></Field></DCArtboard>
        <DCArtboard id="d1-light" label="Light field" width={360} height={360}><Field theme="light"><IconCell2DE size={228} theme="light" /></Field></DCArtboard>
        <DCArtboard id="d1-hero" label="Hero" width={520} height={360} style={{ background: '#0E3B2E' }}>
          <Field theme="dark" style={{ justifyContent: 'flex-start', gap: 36 }} pad={48}>
            <IconCell2DE size={236} theme="dark" />
            <Wordmark size={42} theme="dark" stacked />
          </Field>
        </DCArtboard>
      </DCSection>

      <DCSection id="d2" title="02 · The Glass Week" subtitle="Full M–F lockup; Wednesday is the lit hero column">
        <DCArtboard id="d2-dark" label="Dark" width={620} height={360} style={{ background: '#0E3B2E' }}><Field theme="dark" pad={40}><WeekGrid unit={86} theme="dark" /></Field></DCArtboard>
        <DCArtboard id="d2-light" label="Light" width={620} height={360}><Field theme="light" pad={40}><WeekGrid unit={86} theme="light" /></Field></DCArtboard>
      </DCSection>

      <DCSection id="d3" title="03 · Stacked Lockup" subtitle="Icon over wordmark — for square / vertical placements">
        <DCArtboard id="d3-dark" label="Dark" width={380} height={460} style={{ background: '#0E3B2E' }}>
          <Field theme="dark" style={{ flexDirection: 'column', gap: 26 }}><IconCell2DE size={180} theme="dark" /><Wordmark size={30} theme="dark" stacked /></Field>
        </DCArtboard>
        <DCArtboard id="d3-light" label="Light" width={380} height={460}>
          <Field theme="light" style={{ flexDirection: 'column', gap: 26 }}><IconCell2DE size={180} theme="light" /><Wordmark size={30} theme="light" stacked /></Field>
        </DCArtboard>
      </DCSection>

      <DCSection id="d4" title="04 · Distilled" subtitle="A single calendar tile — Wednesday pip lit. Most minimal direction">
        <DCArtboard id="d4-dark" label="Mark · dark" width={360} height={360} style={{ background: '#0E3B2E' }}><Field theme="dark"><MiniMark size={196} theme="dark" /></Field></DCArtboard>
        <DCArtboard id="d4-light" label="Mark · light" width={360} height={360}><Field theme="light"><MiniMark size={196} theme="light" /></Field></DCArtboard>
        <DCArtboard id="d4-lock" label="Horizontal lockup" width={520} height={360} style={{ background: '#0E3B2E' }}>
          <Field theme="dark" style={{ gap: 30 }}><MiniMark size={150} theme="dark" /><Wordmark size={34} theme="dark" stacked /></Field>
        </DCArtboard>
      </DCSection>

      <DCSection id="d4b" title="04b · Ledger, iconified" subtitle="The systematic strip distilled into a square mark — compare against Distilled above">
        <DCArtboard id="d4b-dark" label="Icon · dark" width={360} height={360} style={{ background: '#0E3B2E' }}><Field theme="dark"><LedgerIcon size={196} theme="dark" /></Field></DCArtboard>
        <DCArtboard id="d4b-light" label="Icon · light" width={360} height={360}><Field theme="light"><LedgerIcon size={196} theme="light" /></Field></DCArtboard>
        <DCArtboard id="d4b-nolabel" label="Strip only" width={360} height={360} style={{ background: '#0E3B2E' }}><Field theme="dark"><LedgerIcon size={196} theme="dark" label={false} /></Field></DCArtboard>
        <DCArtboard id="d4b-lock" label="Horizontal lockup" width={520} height={360} style={{ background: '#0E3B2E' }}>
          <Field theme="dark" style={{ gap: 30 }}><LedgerIcon size={140} theme="dark" label={false} /><Wordmark size={34} theme="dark" stacked /></Field>
        </DCArtboard>
        <DCArtboard id="d4b-ramp" label="Favicon ramp" width={560} height={360}><LedgerIconRamp /></DCArtboard>
      </DCSection>

      <DCSection id="tiles" title="Icon tiles, side by side" subtitle="The three icon candidates as home-screen squircles — this is the clearest read of 'Ledger as a tile'">
        <DCArtboard id="tiles-dark" label="Dark" width={620} height={300} style={{ background: '#0E3B2E' }}><IconTileCompare theme="dark" /></DCArtboard>
        <DCArtboard id="tiles-light" label="Light" width={620} height={300}><IconTileCompare theme="light" /></DCArtboard>
        <DCArtboard id="tiles-ledger-xl" label="Ledger · large" width={360} height={360} style={{ background: '#0E3B2E' }}><Field theme="dark"><LedgerTile size={220} theme="dark" /></Field></DCArtboard>
      </DCSection>

      <DCSection id="d5" title="05 · Ledger" subtitle="Systematic / monospace cut — leans into the finance-syndicate read">
        <DCArtboard id="d5-dark" label="Dark" width={560} height={300} style={{ background: '#0E3B2E' }}><Field theme="dark"><LedgerMark theme="dark" /></Field></DCArtboard>
        <DCArtboard id="d5-light" label="Light" width={560} height={300}><Field theme="light"><LedgerMark theme="light" /></Field></DCArtboard>
      </DCSection>

      <DCSection id="favicons" title="Favicons" subtitle="Legibility ramp from 128 down to 16px, three candidates">
        <DCArtboard id="fav" label="Favicon ramp" width={760} height={520}><Favicons /></DCArtboard>
      </DCSection>

      <DCSection id="motion" title="Motion" subtitle="Animated header — glass sweep across the icon + Wednesday shimmer (loops)">
        <DCArtboard id="header" label="Site header" width={900} height={360} style={{ background: '#0E3B2E' }}><AnimatedHeader /></DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
