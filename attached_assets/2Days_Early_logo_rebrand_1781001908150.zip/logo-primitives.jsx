/* global React */
// ════════════════════════════════════════════════════════════
//  2 Days Early — logo primitives (Structured Liquidity)
//  Reusable glass calendar parts. Exported to window for the app file.
// ════════════════════════════════════════════════════════════

// ── Generic glass calendar cell ──────────────────────────────
function Cell({ size = 64, radius, variant = 'glass', children, style = {}, className = '' }) {
  const r = radius ?? Math.round(size * 0.22);
  return (
    <div
      className={`cell spec ${variant} ${className}`}
      style={{ width: size, height: size, borderRadius: r, fontSize: size * 0.5, ...style }}
    >
      {children}
    </div>
  );
}

// ── The cropped icon mark: W header + 2DE body ───────────────
// This is the faithful re-cut of the existing app icon, rebuilt in glass.
function IconCell2DE({ size = 240, theme = 'dark' }) {
  const dark = theme === 'dark';
  const pad = size * 0.06;
  const headerH = size * 0.30;
  return (
    <div
      className={`spec ${dark ? 'glass-forest' : 'glass-mint'}`}
      style={{
        width: size, height: size, borderRadius: size * 0.2,
        padding: pad, boxSizing: 'border-box',
        display: 'flex', flexDirection: 'column', gap: pad * 0.9,
        position: 'relative',
      }}
    >
      {/* W — the Wednesday tab (the "2 days early" punchline) */}
      <div
        style={{
          height: headerH, display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: 'var(--font-grotesque)', fontWeight: 800,
          fontSize: size * 0.2, letterSpacing: '-0.02em',
          color: dark ? 'var(--mint)' : 'var(--forest)',
          textShadow: dark ? '0 1px 0 rgba(0,0,0,0.25)' : '0 1px 0 rgba(255,255,255,0.6)',
        }}
      >
        W
      </div>
      {/* 2DE body panel */}
      <div
        className="spec"
        style={{
          flex: 1, borderRadius: size * 0.12,
          background: dark
            ? 'linear-gradient(155deg, rgba(255,255,255,0.96), rgba(232,247,240,0.9))'
            : 'linear-gradient(155deg, rgba(255,255,255,0.98), rgba(244,251,247,0.95))',
          boxShadow: 'inset 0 2px 0 rgba(255,255,255,0.9), inset 0 -10px 20px rgba(20,90,60,0.12), 0 6px 16px rgba(5,40,28,0.18)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: 'var(--font-grotesque)', fontWeight: 900,
          fontSize: size * 0.36, letterSpacing: '-0.04em', position: 'relative',
        }}
      >
        <span style={{ color: 'var(--forest)' }}>2</span>
        <span style={{ color: 'var(--emerald)' }}>DE</span>
      </div>
    </div>
  );
}

// ── Full week-grid lockup: M T W T F / 2 D A Y S / E A R L Y ──
function WeekGrid({ unit = 86, theme = 'dark', gap = 7 }) {
  const dark = theme === 'dark';
  const days = ['M', 'T', 'W', 'T', 'F'];
  const row1 = ['2', 'D', 'A', 'Y', 'S'];
  const row2 = ['E', 'A', 'R', 'L', 'Y'];
  const r = Math.round(unit * 0.16);

  const Head = ({ d, hero }) => (
    <div
      className="spec glass-forest"
      style={{
        width: unit, height: unit * 0.62, borderRadius: r,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: 'var(--font-grotesque)', fontWeight: 800, fontSize: unit * 0.34,
        color: hero ? 'var(--mint)' : 'var(--emerald-300)', letterSpacing: '-0.02em',
      }}
    >
      {d}
    </div>
  );

  const Body = ({ ch, hero, first }) => (
    <div
      className={`spec ${hero ? 'glass-emerald' : ''}`}
      style={{
        width: unit, height: unit, borderRadius: r,
        background: hero ? undefined : (dark
          ? 'linear-gradient(155deg, rgba(255,255,255,0.95), rgba(228,245,237,0.88))'
          : 'linear-gradient(155deg, #FFFFFF, #F1F8F4)'),
        boxShadow: hero ? undefined
          : 'inset 0 1.5px 0 rgba(255,255,255,0.9), inset 0 -10px 18px rgba(20,90,60,0.10), 0 6px 16px rgba(5,40,28,0.16)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: 'var(--font-grotesque)', fontWeight: 900, fontSize: unit * 0.5,
        letterSpacing: '-0.04em',
        color: hero ? '#FFFFFF' : (first ? 'var(--forest)' : 'var(--emerald)'),
        textShadow: hero ? '0 1px 2px rgba(7,55,37,0.45)' : 'none',
        position: 'relative',
      }}
    >
      {ch}
    </div>
  );

  return (
    <div className="cal" style={{ gridTemplateColumns: `repeat(5, ${unit}px)`, gap }}>
      {days.map((d, i) => <Head key={'h' + i} d={d} hero={i === 2} />)}
      {row1.map((c, i) => <Body key={'a' + i} ch={c} hero={i === 2} first={i === 0} />)}
      {row2.map((c, i) => <Body key={'b' + i} ch={c} hero={i === 2} />)}
    </div>
  );
}

// ── Wordmark ─────────────────────────────────────────────────
function Wordmark({ size = 48, theme = 'dark', stacked = false, mono = false }) {
  const dark = theme === 'dark';
  const c1 = dark ? 'var(--white)' : 'var(--forest)';
  const c2 = dark ? 'var(--emerald-bright)' : 'var(--emerald)';
  if (stacked) {
    return (
      <div className={mono ? 'wm-mono' : 'wm'} style={{ fontSize: size, color: c1 }}>
        <div>2 DAYS</div>
        <div style={{ color: c2 }}>EARLY</div>
      </div>
    );
  }
  return (
    <div className={mono ? 'wm-mono' : 'wm'} style={{ fontSize: size, color: c1, whiteSpace: 'nowrap' }}>
      2 DAYS <span style={{ color: c2 }}>EARLY</span>
    </div>
  );
}

// ── Abstracted minimal mark: a single glass calendar tile ────
// A forest tile with a Wednesday "binding" tab, big 2DE, one mint pip row.
function MiniMark({ size = 240, theme = 'dark', tabs = true, pips = true }) {
  const dark = theme === 'dark';
  return (
    <div style={{ width: size, height: size, position: 'relative' }}>
      {/* calendar binding tabs */}
      {tabs && (
        <div style={{ position: 'absolute', top: -size * 0.04, left: 0, right: 0, display: 'flex', justifyContent: 'center', gap: size * 0.12, zIndex: 2 }}>
          {[0, 1].map((i) => (
            <div key={i} style={{ width: size * 0.05, height: size * 0.11, borderRadius: size * 0.025, background: dark ? 'var(--mint)' : 'var(--forest)', boxShadow: '0 2px 4px rgba(0,0,0,0.25)' }} />
          ))}
        </div>
      )}
      <div
        className={`spec ${dark ? 'glass-forest' : 'glass-mint'}`}
        style={{ width: size, height: size, borderRadius: size * 0.22, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: size * 0.06 }}
      >
        <div style={{ fontFamily: 'var(--font-grotesque)', fontWeight: 900, fontSize: size * 0.40, letterSpacing: '-0.05em', lineHeight: 0.85 }}>
          <span style={{ color: dark ? 'var(--white)' : 'var(--forest)' }}>2</span>
          <span style={{ color: 'var(--emerald-bright)' }}>DE</span>
        </div>
        {/* week pips — Wednesday lit */}
        {pips && (
          <div style={{ display: 'flex', gap: size * 0.035 }}>
            {[0, 1, 2, 3, 4].map((i) => (
              <div key={i} style={{ width: size * 0.07, height: size * 0.022, borderRadius: 999, background: i === 2 ? 'var(--emerald-bright)' : (dark ? 'rgba(155,247,210,0.32)' : 'rgba(14,59,46,0.25)') }} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { Cell, IconCell2DE, WeekGrid, Wordmark, MiniMark });
