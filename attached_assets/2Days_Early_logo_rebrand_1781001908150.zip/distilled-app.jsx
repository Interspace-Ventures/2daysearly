/* global React, ReactDOM */
// ════════════════════════════════════════════════════════════
//  2 Days Early — DISTILLED · placement specimen
// ════════════════════════════════════════════════════════════
const { MiniMark, Wordmark } = window;
const MONO = 'var(--font-mono)';
const GROT = 'var(--font-grotesque)';

// ── primitives ───────────────────────────────────────────────
function SecLabel({ children, n }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginBottom: 18 }}>
      {n && <span style={{ fontFamily: MONO, fontSize: 12, color: '#9aa79d', fontWeight: 500 }}>{n}</span>}
      <span style={{ fontFamily: MONO, fontSize: 12, letterSpacing: '0.14em', textTransform: 'uppercase', color: '#5c6b5f', fontWeight: 500 }}>{children}</span>
      <span style={{ flex: 1, height: 1, background: 'rgba(14,59,46,0.12)', alignSelf: 'center' }} />
    </div>
  );
}

// a panel that fills with a dark or light brand field
function Panel({ theme = 'dark', children, h = 200, label, style = {} }) {
  const dark = theme === 'dark';
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 9, flex: 1, minWidth: 0 }}>
      <div
        className={`grain ${dark ? 'field-dark' : 'field-light'}`}
        style={{
          height: h, borderRadius: 16, display: 'flex', alignItems: 'center', justifyContent: 'center',
          position: 'relative', overflow: 'hidden',
          boxShadow: dark ? '0 1px 2px rgba(0,0,0,0.2)' : 'inset 0 0 0 1px rgba(14,59,46,0.07)',
          ...style,
        }}
      >
        {children}
      </div>
      {label && <div style={{ fontFamily: MONO, fontSize: 11, color: '#8a978c', letterSpacing: '0.04em' }}>{label}</div>}
    </div>
  );
}

// ── lockups ──────────────────────────────────────────────────
function Lockup({ theme = 'dark', layout = 'left', iconSize = 60 }) {
  const dark = theme === 'dark';
  const wm = (
    <Wordmark size={layout === 'above' ? 26 : iconSize * 0.37} theme={theme} stacked />
  );
  const icon = <MiniMark size={iconSize} theme={theme} />;
  if (layout === 'above') {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20 }}>
        {icon}
        <div style={{ textAlign: 'center' }}>{wm}</div>
      </div>
    );
  }
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: iconSize * 0.34, flexDirection: layout === 'right' ? 'row-reverse' : 'row' }}>
      {icon}
      {wm}
    </div>
  );
}

// ── navbar mock ──────────────────────────────────────────────
function Navbar({ theme = 'dark' }) {
  const dark = theme === 'dark';
  const link = { fontFamily: GROT, fontWeight: 600, fontSize: 14, color: dark ? 'rgba(234,251,241,0.82)' : 'rgba(14,59,46,0.78)' };
  return (
    <div className={`grain ${dark ? 'field-dark' : 'field-light'}`} style={{ borderRadius: 16, overflow: 'hidden', boxShadow: dark ? '0 1px 2px rgba(0,0,0,0.2)' : 'inset 0 0 0 1px rgba(14,59,46,0.07)' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px 26px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 13 }}>
          <MiniMark size={36} theme={theme} tabs={false} pips={false} />
          <span className="wm" style={{ fontSize: 17, color: dark ? '#fff' : 'var(--forest)' }}>
            2 DAYS <span style={{ color: dark ? 'var(--emerald-bright)' : 'var(--emerald)' }}>EARLY</span>
          </span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 26 }}>
          <span style={link}>Thesis</span>
          <span style={link}>Portfolio</span>
          <span style={link}>Founders</span>
          <span style={{ fontFamily: GROT, fontWeight: 800, fontSize: 13.5, color: dark ? 'var(--forest)' : '#fff', background: dark ? 'var(--emerald-bright)' : 'var(--forest)', padding: '8px 16px', borderRadius: 9 }}>Apply</span>
        </div>
      </div>
    </div>
  );
}

// ── 2 vs 2DE favicon A/B ─────────────────────────────────────
function TabChip({ force }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: '#fff', padding: '8px 12px', borderRadius: 9, boxShadow: '0 4px 14px rgba(14,59,46,0.12)', maxWidth: 200 }}>
      <FavMark px={16} force={force} />
      <span style={{ fontFamily: GROT, fontWeight: 600, fontSize: 12, color: '#2d3a31', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>2 Days Early</span>
    </div>
  );
}
function Mag({ force, scale = 4.5 }) {
  const s = 16 * scale;
  return (
    <div style={{ width: s, height: s, overflow: 'hidden', borderRadius: 8, boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.08)' }}>
      <div style={{ width: 16, height: 16, transform: `scale(${scale})`, transformOrigin: 'top left' }}>
        <FavMark px={16} force={force} />
      </div>
    </div>
  );
}
function FaviconAB() {
  const Col = ({ force, name, note, pick }) => (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16, padding: '4px 8px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <span style={{ fontFamily: GROT, fontWeight: 800, fontSize: 15, color: '#fff' }}>“{name}”</span>
        {pick && <span style={{ fontFamily: MONO, fontSize: 9.5, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--forest)', background: 'var(--emerald-bright)', padding: '3px 8px', borderRadius: 999, fontWeight: 700, whiteSpace: 'nowrap' }}>winner</span>}
      </div>
      <Mag force={force} />
      <TabChip force={force} />
      <div style={{ fontFamily: MONO, fontSize: 10.5, lineHeight: 1.5, color: 'rgba(167,240,198,0.62)', textAlign: 'center', maxWidth: 190 }}>{note}</div>
    </div>
  );
  return (
    <div className="grain field-dark" style={{ borderRadius: 16, padding: '34px 24px', position: 'relative', overflow: 'hidden' }}>
      <div style={{ fontFamily: MONO, fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'rgba(167,240,198,0.6)', textAlign: 'center', marginBottom: 26 }}>
        the same favicon at 16px — magnified 4.5× &amp; in a real tab
      </div>
      <div style={{ display: 'flex', gap: 20 }}>
        <Col force="full" name="2DE" note="three glyphs share ~16px → ≈5px each. Muddies into a green blob; the D/E fuse." />
        <Col force="2" name="2" pick note="one confident numeral. Crisp, and “2” is already the brand's hero number." />
      </div>
    </div>
  );
}

// ── favicon / tab mock ───────────────────────────────────────
function FavMark({ px = 32, force }) {
  // simplified Distilled for tiny use: forest squircle + 2DE; bold 2 at ≤20
  const small = force ? force === '2' : px <= 20;
  return (
    <div className="spec glass-forest" style={{ width: px, height: px, borderRadius: px * 0.24, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <span style={{ fontFamily: GROT, fontWeight: 900, letterSpacing: '-0.05em', lineHeight: 1, fontSize: small ? px * 0.6 : px * 0.36 }}>
        {small ? <span style={{ color: 'var(--emerald-bright)' }}>2</span>
          : (<><span style={{ color: '#fff' }}>2</span><span style={{ color: 'var(--emerald-bright)' }}>DE</span></>)}
      </span>
    </div>
  );
}

function BrowserTab() {
  return (
    <div style={{ width: '100%', maxWidth: 420, borderRadius: '12px 12px 0 0', overflow: 'hidden', boxShadow: '0 10px 30px rgba(14,59,46,0.14)', background: '#fff' }}>
      <div style={{ background: '#e9e6df', padding: '10px 12px 0', display: 'flex', gap: 8, alignItems: 'flex-end' }}>
        <div style={{ display: 'flex', gap: 6, paddingBottom: 9 }}>
          {['#f0685f', '#f5bd4f', '#62c554'].map((c) => <span key={c} style={{ width: 11, height: 11, borderRadius: 6, background: c }} />)}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: '#fff', padding: '9px 14px', borderRadius: '9px 9px 0 0', maxWidth: 230 }}>
          <FavMark px={16} />
          <span style={{ fontFamily: GROT, fontWeight: 600, fontSize: 12.5, color: '#2d3a31', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>2 Days Early — Syndicate</span>
          <span style={{ color: '#aab4ac', fontSize: 13 }}>×</span>
        </div>
      </div>
      <div style={{ height: 8, background: '#fff' }} />
    </div>
  );
}

// ── page ─────────────────────────────────────────────────────
function Row({ children }) {
  return <div style={{ display: 'flex', gap: 20 }}>{children}</div>;
}

function App() {
  return (
    <div style={{ minHeight: '100vh', background: '#F0EEE8', padding: '0 0 100px' }}>
      <div style={{ maxWidth: 1080, margin: '0 auto', padding: '0 40px' }}>

        {/* header */}
        <header style={{ padding: '64px 0 44px', borderBottom: '1px solid rgba(14,59,46,0.12)', marginBottom: 56 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 22 }}>
            <MiniMark size={30} theme="light" tabs={false} pips={false} />
            <span style={{ fontFamily: MONO, fontSize: 12.5, letterSpacing: '0.12em', textTransform: 'uppercase', color: '#5c6b5f' }}>2 Days Early · Brand</span>
          </div>
          <h1 style={{ fontFamily: GROT, fontWeight: 900, fontSize: 52, letterSpacing: '-0.035em', color: 'var(--forest)', margin: 0, lineHeight: 0.98 }}>
            Distilled <span style={{ color: 'var(--emerald)' }}>— placements</span>
          </h1>
          <p style={{ fontFamily: GROT, fontWeight: 500, fontSize: 16, color: '#5c6b5f', maxWidth: 560, marginTop: 16, lineHeight: 1.5 }}>
            The distilled calendar tile across the placements you'll actually use — on light and dark fields.
          </p>
        </header>

        {/* THE MARK */}
        <section style={{ marginBottom: 64 }}>
          <SecLabel n="01">The mark</SecLabel>
          <Row>
            <Panel theme="dark" h={300} label="on forest"><MiniMark size={172} theme="dark" /></Panel>
            <Panel theme="light" h={300} label="on paper"><MiniMark size={172} theme="light" /></Panel>
          </Row>
        </section>

        {/* HORIZONTAL — ICON LEFT */}
        <section style={{ marginBottom: 64 }}>
          <SecLabel n="02">Icon left of wordmark</SecLabel>
          <Row>
            <Panel theme="dark" h={210} label="primary horizontal lockup"><Lockup theme="dark" layout="left" iconSize={68} /></Panel>
            <Panel theme="light" h={210} label="primary horizontal lockup"><Lockup theme="light" layout="left" iconSize={68} /></Panel>
          </Row>
        </section>

        {/* HORIZONTAL — ICON RIGHT */}
        <section style={{ marginBottom: 64 }}>
          <SecLabel n="03">Icon right of wordmark</SecLabel>
          <Row>
            <Panel theme="dark" h={210} label="trailing icon"><Lockup theme="dark" layout="right" iconSize={68} /></Panel>
            <Panel theme="light" h={210} label="trailing icon"><Lockup theme="light" layout="right" iconSize={68} /></Panel>
          </Row>
        </section>

        {/* STACKED — ICON ABOVE */}
        <section style={{ marginBottom: 64 }}>
          <SecLabel n="04">Icon above wordmark</SecLabel>
          <Row>
            <Panel theme="dark" h={300} label="vertical / centered lockup"><Lockup theme="dark" layout="above" iconSize={92} /></Panel>
            <Panel theme="light" h={300} label="vertical / centered lockup"><Lockup theme="light" layout="above" iconSize={92} /></Panel>
          </Row>
        </section>

        {/* NAVBAR */}
        <section style={{ marginBottom: 64 }}>
          <SecLabel n="05">In a navbar</SecLabel>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <Navbar theme="dark" />
            <Navbar theme="light" />
          </div>
          <div style={{ fontFamily: MONO, fontSize: 11, color: '#8a978c', letterSpacing: '0.04em', marginTop: 10 }}>navbar icon drops the binding tabs & pips for a clean, compact lockup</div>
        </section>

        {/* FAVICON */}
        <section>
          <SecLabel n="06">Favicon &amp; app icon</SecLabel>
          <Row>
            <Panel theme="light" h={260} label="browser tab @ real size" style={{ alignItems: 'flex-end', paddingTop: 28 }}>
              <BrowserTab />
            </Panel>
            <Panel theme="dark" h={260} label="favicon ramp · 16 → 64px">
              <div style={{ display: 'flex', alignItems: 'flex-end', gap: 26 }}>
                {[64, 48, 32, 16].map((px) => (
                  <div key={px} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 9 }}>
                    <FavMark px={px} />
                    <span style={{ fontFamily: MONO, fontSize: 10, color: 'rgba(167,240,198,0.5)' }}>{px}</span>
                  </div>
                ))}
              </div>
            </Panel>
          </Row>
          <div style={{ fontFamily: MONO, fontSize: 11, color: '#8a978c', letterSpacing: '0.04em', marginTop: 10, marginBottom: 22 }}>
            favicon simplifies to “2DE”; at 16px it reduces to a single bold “2” for clarity
          </div>
          <FaviconAB />
        </section>

      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
